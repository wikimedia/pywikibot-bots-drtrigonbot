slic-python
===========

SLIC Superpixel implementation wrapper for Python